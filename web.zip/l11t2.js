// Get the current date and time
const now = new Date();
const currentHour = now.getHours();

// Initialize greeting message
let greeting;

// Determine the appropriate greeting based on the current hour
if (currentHour >= 5 && currentHour < 12) {
    greeting = "Good morning!";
} else if (currentHour >= 12 && currentHour < 18) {
    greeting = "Good afternoon!";
} else {
    greeting = "Good evening!";
}

// Display the greeting message in an alert box
alert(greeting);
